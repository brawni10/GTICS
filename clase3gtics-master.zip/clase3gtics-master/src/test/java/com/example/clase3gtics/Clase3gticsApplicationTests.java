package com.example.clase3gtics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Clase3gticsApplicationTests {

    @Test
    void contextLoads() {
    }

}
