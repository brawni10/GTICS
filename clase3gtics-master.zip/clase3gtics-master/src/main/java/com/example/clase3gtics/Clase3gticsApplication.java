package com.example.clase3gtics;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clase3gticsApplication {

    public static void main(String[] args) {
        SpringApplication.run(Clase3gticsApplication.class, args);
    }

}
